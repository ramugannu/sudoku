/**
 * 
 */
package com.company.validation;

import org.junit.Before;
import org.junit.Test;

public class AppTest {
	
	private String[][] board ;
	
	private String validPath;
	
	private String invalidPath;
	
	private String invalidPath1;
	
	@Before
	public void before() throws Exception {
		validPath = getClass().getClassLoader().getResource("board1.txt").toURI().toString();
		validPath = validPath.substring(validPath.indexOf(":")+1);
		
		invalidPath = getClass().getClassLoader().getResource("board.txt").toURI().toString();
		invalidPath = invalidPath.substring(invalidPath.indexOf(":")+1);
		
		invalidPath1 = getClass().getClassLoader().getResource("board2.txt").toURI().toString();
		invalidPath1 = invalidPath1.substring(invalidPath1.indexOf(":")+1);
	}
	
	
	@Test
	public void validTest() {
		
		App app = new App();
		
		app.setFilePath(validPath);
		
		app.run();
		
	}
	
	@Test
	public void inValidTest() {
		
		App app = new App();
		
		app.setFilePath(invalidPath);
		
		app.run();
		
	}
	
	@Test
	public void inValidTest1() {
		
		App app = new App();
		
		app.setFilePath(invalidPath1);
		
		app.run();
		
	}

}
