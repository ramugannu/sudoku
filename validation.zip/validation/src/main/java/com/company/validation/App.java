package com.company.validation;

import java.util.ArrayList;
import java.util.List;

import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Parameters;

import java.io.*;

/**
 * Hello world!
 */
@Command(name = "Validation", description = "Validate the given file [filePath]")
public final class App implements Runnable {

	@Parameters(index = "0", description = "file path to validate")
	private String filePath;	
	

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	// Checks whether there is any duplicate in current row or not
	public static boolean checkRow(String arr[][], int row) {
		List<String> st = new ArrayList<>();

		for (int i = 0; i < 9; i++) {

			// If already Present in the row will stop and return error
			if (st.contains(arr[row][i])) {
				return false;
			}

			st.add(arr[row][i]);
		}
		return true;
	}

	// Checks whether there is any duplicate in current column or not.
	public static boolean checkCol(String arr[][], int col) {

		List<String> st = new ArrayList<>();

		for (int i = 0; i < 9; i++) {

			// If already Present in the col will stop and return error
			if ( conNum(arr[i][col]) < 0 || conNum(arr[i][col]) > 9 || st.contains(arr[i][col])) {

				return false;
			}

			st.add(arr[i][col]);
		}
		return true;
	}

	// Checks whether there is any duplicate in 3x3 grid or not.
	public static boolean checkGrid(String arr[][], int startRow, int startCol) {
		List<String> st = new ArrayList<>();

		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				String curr = arr[row + startRow][col + startCol];

				// If already present in the grid will return error
				if (st.contains(curr)) {

					return false;
				}

				st.add(curr);
			}
		}
		return true;
	}

	public static String isValidConfig(String arr[][], int n) {

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {

				if (!(checkGrid(arr, i - i % 3, j - j % 3))) {
					return "invalid :: ErrorCode : 201 - Duplicate Found  in the grid starting row no :" + (i+1) ;
				} else if(!checkRow(arr, i)) {
					return "invalid :: ErrorCode : 202 - Duplicate Found  in the row :" + (i+1) ;
				}else if(!checkCol(arr, j)) {
					return "invalid :: ErrorCode : 202 - Duplicate/Invalid value Found  in the col :" + (j+1) ;
				}

			}
		}
		return "Valid";
	}

	static int conNum(String val) {

		try {
			int num = Integer.parseInt(val + "");
			return num;
		} catch (Exception e) {
			return 21;
		}

	}

	public static void main(String[] args) throws Exception {
		new CommandLine(new App()).execute(args);

	}

	@Override
	public void run() {

		String[][] board = new String[9][];

		try {
			File file = new File(filePath);
			BufferedReader br = new BufferedReader(new FileReader(file));
			String st;
			int rowCount = 0;
			while ((st = br.readLine()) != null) {
				if (!st.isEmpty()) {
					board[rowCount] = st.split(",");
					if(board[rowCount].length != 9) {
						throw new Exception("invalid coulmns in row " + rowCount+1 + ". Should contain 9 columns");						
					}
					rowCount++;
				}
			}
			if(rowCount != 9) {
				throw new Exception("invalid row Count " + rowCount+ ", Should Contain 9 rows");
				
			}

			System.out.println(isValidConfig(board, 9));

		} catch (FileNotFoundException e) {
			System.out.println("Invalid file path or cannot read the file");
		} catch (IOException e) {
			System.out.println("Error occured while reading the File");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
